import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar } from '@ionic/angular/standalone';

@Component({
  selector: 'app-listar-cuentas',
  templateUrl: './listar-cuentas.page.html',
  styleUrls: ['./listar-cuentas.page.scss'],
  standalone: true,
  imports: [IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule]
})
export class ListarCuentasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
