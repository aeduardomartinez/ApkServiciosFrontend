import { Component, inject } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cuentas',
  templateUrl: './cuentas.page.html',
  styleUrls: ['./cuentas.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule],
})
export class CuentasPage {
  private readonly router = inject(Router);

  goListar(): void {
    this.router.navigate(['/tabs/cuentas/listar']);
  }

  goCrear(): void {
    this.router.navigate(['/tabs/cuentas/crear']);
  }
}
