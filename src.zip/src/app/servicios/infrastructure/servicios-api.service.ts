
import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { CrearServicioRequest, ServicioListItem, ServicioResponse } from '../domain/servicio.models';
import { CrearCuentaRequest,CuentaResponse } from '../domain/cuenta.models';

@Injectable({ providedIn: 'root' })
export class ServiciosApiService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiBaseUrl;

  crearServicio(payload: CrearServicioRequest): Observable<ServicioResponse> {
    return this.http.post<ServicioResponse>(`${this.baseUrl}/api/crearServicio`, payload);
  }

  crearCuenta(payload: CrearCuentaRequest): Observable<CuentaResponse> {
    return this.http.post<CuentaResponse>(`${this.baseUrl}/api/cuentas/crear`, payload);
  }

  listarServicios(): Observable<ServicioListItem[]> {
    return this.http.get<ServicioListItem[]>(`${this.baseUrl}/api/servicios`);
  }
}
