import { Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

export const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'tab1',
        loadComponent: () =>
          import('../tab1/tab1.page').then((m) => m.Tab1Page),
      },
      {
         path: 'tab2',
         loadComponent: () =>
             import('../pages/cuentas/cuentas.page').then((m) => m.CuentasPage),
          children: [
             { path: '', redirectTo: 'crear', pathMatch: 'full' },
              {
              path: 'crear',
               loadComponent: () =>
                   import('../pages/crear-cuenta/crear-cuenta.page').then((m) => m.CrearCuentaPage),
                 },
                {
              path: 'listar',
                   loadComponent: () =>
                        import('../pages/listar-cuentas/listar-cuentas.page').then((m) => m.ListarCuentasPage),
                 },
           ],
         },
      {
        path: 'tab3',
        loadComponent: () =>
          import('../tab3/tab3.page').then((m) => m.Tab3Page),
      },
      {
        path: '',
        redirectTo: '/tabs/tab1',
        pathMatch: 'full',
      },
    ],
  },
  {
    path: '',
    redirectTo: '/tabs/tab1',
    pathMatch: 'full',
  },
];
