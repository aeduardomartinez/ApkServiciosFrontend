import { Component, inject } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ListarCuentasPage } from '../listar-cuentas/listar-cuentas.page';
import { CrearCuentaPage } from '../crear-cuenta/crear-cuenta.page';
import { addIcons } from 'ionicons';
import { tvOutline, eyeOutline, listOutline, addCircleOutline, chevronDownOutline } from 'ionicons/icons';
type CuentasView = 'none' | 'crear' | 'listar';
@Component({
  selector: 'app-cuentas',
  templateUrl: './cuentas.page.html',
  styleUrls: ['./cuentas.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, CrearCuentaPage, ListarCuentasPage],
})
export class CuentasPage {


 view: CuentasView = 'none';

 isMenuOpen = false;

  openMenu(): void {
    this.isMenuOpen = true;
  }
  closeMenu(): void {
    this.isMenuOpen = false;
  }
  setView(v: CuentasView): void {
    this.view = v;
    this.closeMenu();
  }
}
