import { Component, OnInit,inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { CuentaListResponse, PerfilResponse } from 'src/app/servicios/domain/cuenta.models';
import { ListarCuentasUseCase } from 'src/app/servicios/application/listar-cuentas.usecase';
import { addIcons } from 'ionicons';
import { tvOutline, eyeOutline, listOutline, addCircleOutline, chevronDownOutline } from 'ionicons/icons';
type CuentaUi = CuentaListResponse & {
  expanded?: boolean;
  showClave?: boolean; // si luego quieres mostrar/ocultar (por ahora solo UI)
};

@Component({
  selector: 'app-listar-cuentas',
  templateUrl: './listar-cuentas.page.html',
  styleUrls: ['./listar-cuentas.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule],
})
export class ListarCuentasPage implements OnInit {

  private readonly listarCuentas = inject(ListarCuentasUseCase);

  loading = false;

  cuentas: CuentaUi[] = [];
  filtered: CuentaUi[] = [];

  private search = '';

  ngOnInit(): void {
    // ✅ Carga todas las cuentas del servicio 1 (cámbialo si lo quieres dinámico)
    this.load();
  }

  load(servicio?: number): void {
    this.loading = true;

    this.listarCuentas.execute(servicio).subscribe({
      next: (data: CuentaListResponse[]) => {
        this.cuentas = (data ?? []).map((c) => ({
          ...c,
          expanded: false,
          showClave: false,
        }));

        this.applyFilter();
        this.loading = false;
      },
      error: (err: unknown) => {
        console.error(err);
        this.loading = false;
      },
    });
  }

  // ========== Search ==========
  onSearch(ev: CustomEvent): void {
    this.search = (ev.detail?.value ?? '').toString();
    this.applyFilter();
  }

  private applyFilter(): void {
    const q = this.search.trim().toLowerCase();

    if (!q) {
      this.filtered = [...this.cuentas];
      return;
    }

    this.filtered = this.cuentas.filter((c) => {
      const matchCuenta =
        (c.servicioNombre ?? '').toLowerCase().includes(q) ||
        (c.correo ?? '').toLowerCase().includes(q);

      const matchPerfil = (c.perfiles ?? []).some((p) => {
        const nombre = (p.nombreCliente ?? '').toLowerCase();
        const estado = (p.estado ?? '').toLowerCase();
        return nombre.includes(q) || estado.includes(q);
      });

      return matchCuenta || matchPerfil;
    });
  }

  // ========== TrackBy ==========
  trackByCuentaId(_: number, item: CuentaUi): number {
    return item.id;
  }

 trackByPerfilId(_: number, item: PerfilResponse): string {
    return item.id;
  }
  // ========== UI toggles ==========
  toggleExpanded(c: CuentaUi): void {
    c.expanded = !c.expanded;
    // OJO: si quieres limitar la cantidad visible, lo hacemos en el HTML con un slice
  }

  toggleClave(c: CuentaUi): void {
    c.showClave = !c.showClave;
  }

  // ========== Formateadores ==========
  formatPerfilNombre(p: PerfilResponse): string {
    return p.nombreCliente?.trim() || 'LIBRE';
  }

  formatFecha(value: string | null | undefined): string {
    if (!value) return '—';
    // "YYYY-MM-DD" -> "DD/MM/YYYY"
    const [y, m, d] = value.split('-');
    return `${d}/${m}/${y}`;
  }

  estadoLabel(estado: string): string {
    switch ((estado ?? '').toUpperCase()) {
      case 'ACTIVO': return 'Activo';
      case 'LIBRE': return 'Libre';
      case 'VENCIDO': return 'Vencido';
      case 'VENCE_HOY': return 'Vence hoy';
      case 'PROXIMO': return 'Próximo';
      default: return estado;
    }
  }

  estadoClass(estado: string): string {
    switch ((estado ?? '').toUpperCase()) {
      case 'ACTIVO': return 'chip chip--ok';
      case 'LIBRE': return 'chip chip--info';
      case 'VENCE_HOY': return 'chip chip--warn';
      case 'VENCIDO': return 'chip chip--danger';
      default: return 'chip';
    }
  }

  // ========== Badge de cuenta (solo informativo) ==========
  // Como tú dijiste: el estado es por perfil, no por cuenta.
  // Entonces este badge puede ser SOLO "Vence: DD/MM/YYYY" o "Cuenta"
  cuentaBadgeLabel(c: CuentaUi): string {
    return `Vence: ${this.formatFecha(c.fechaFin)}`;
  }

  cuentaBadgeClass(_: CuentaUi): string {
    return 'badge--neutral';
  }
}
