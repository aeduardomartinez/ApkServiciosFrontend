
import { inject, Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { CrearServicioRequest, ServicioListItem, ServicioResponse } from '../domain/servicio.models';
import { CrearCuentaRequest,CuentaListResponse,CuentaResponse } from '../domain/cuenta.models';

@Injectable({ providedIn: 'root' })
export class ServiciosApiService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = environment.apiBaseUrl;

  crearServicio(payload: CrearServicioRequest): Observable<ServicioResponse> {
    return this.http.post<ServicioResponse>(`${this.baseUrl}/api/servicios`, payload);
  }

  crearCuenta(payload: CrearCuentaRequest): Observable<CuentaResponse> {
    return this.http.post<CuentaResponse>(`${this.baseUrl}/api/cuentas/crear`, payload);
  }

  listarServicios(): Observable<ServicioListItem[]> {
    return this.http.get<ServicioListItem[]>(`${this.baseUrl}/api/servicios`);
  }


 listarCuentas(servicio?: number): Observable<CuentaListResponse[]> {
  let params = new HttpParams();

  if (servicio !== undefined && servicio !== null) {
    params = params.set('servicio', String(servicio));
  }

  return this.http.get<CuentaListResponse[]>(
    `${this.baseUrl}/api/cuentas`,
    { params }
  );

 }
}
