export interface CrearCuentaRequest {
  servicioId: number;
  clave: string;
  correo: string;
  fechaInicio: string;
  fechaFin: string;
}

export interface CuentaResponse {
  id: string;
  servicio: string;
  correo: string;
  fechaInicio: string;
  fechaFin: string;
  perfiles: PerfilResponse[];
}

export interface PerfilResponse {
  id: string;
  nombreCliente: string;
  telefono: string;
  fechaInicio: string;
  fechaFin: string;
   estado: string;
}

export interface CuentaListResponse {
  id: number;
  servicio: string;
  servicioNombre: string;
  correo: string;
  fechaInicio: string;
  fechaFin: string;
  perfiles: PerfilResponse[];
}
